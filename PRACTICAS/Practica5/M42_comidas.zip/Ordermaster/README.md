# IS-practicas-enunciados
Enunciados de prácticas de la asignatura de Ingeniería del Software, Grado de Ingeniería Informática, Escuela de Ingeniería y Arquitectura, Universidad de Zaragoza.

Esta rama contiene el código correspondiente a la aplicación Notepad presentada en la práctica 2.
