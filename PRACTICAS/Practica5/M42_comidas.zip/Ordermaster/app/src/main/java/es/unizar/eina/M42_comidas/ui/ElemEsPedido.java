package es.unizar.eina.M42_comidas.ui;

/** Clase utilizada para guardar los platos en un pedido */
public class ElemEsPedido {
    
    public int platoId;
    public int cantidad;
    public double precio;
}
